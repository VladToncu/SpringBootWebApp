package com.jpmorgan.sample;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class SampleController {

    @RequestMapping("/CallServer")
    @ResponseBody
    String home() {
        return "Hello this is response from REST Web server!";
    }
}